<?php

$config = array(

	/*
	* ADMIN ACCESS CREDENTIALS
	*/
	'admin_username' => 'admin', // username used to login to the admin area
	'admin_password' => 'admin', // password used to login to the admin area

	/*
	* DATABASE ACCESS CREDENTIALS
	*/
	'db_host' => 'localhost', // database host, usually localhost
	'db_username' => 'dev_viitgo', // database username
	'db_password' => 'NnoK[Bt-T!W1', // datebase password
	'db_name' => 'dev_viitgo', // database name

);