<?php

class Proposals extends Model {
	public static $_table = 'proposals';

}