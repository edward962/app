<?php

class Requests extends Model {
	public static $_table = 'requests';

}