<?php

class Pages extends Model {
	public static $_table = 'pages';

}