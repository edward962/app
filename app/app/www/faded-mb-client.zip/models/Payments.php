<?php

class Payments extends Model {
	public static $_table = 'payments';

}