<?php

class Reviews extends Model {
	public static $_table = 'reviews';

}