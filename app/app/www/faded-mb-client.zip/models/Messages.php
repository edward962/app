<?php

class Messages extends Model {
	public static $_table = 'messages';

}