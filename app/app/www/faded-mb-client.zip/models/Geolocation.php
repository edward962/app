<?php

class Geolocation extends Model {
	public static $_table = 'geolocation';

}