<?php

class Keys extends Model {
	public static $_table = 'keys';

}