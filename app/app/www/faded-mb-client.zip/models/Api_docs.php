<?php

class Api_docs extends Model {
	public static $_table = 'api_docs';

}