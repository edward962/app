<?php

class Users extends Model {
	public static $_table = 'users';

}