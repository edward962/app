<?php

class Blogs extends Model {
	public static $_table = 'blogs';

}